import Head from "next/head";
import { Container } from "@chakra-ui/react";
import { FC, useMemo } from "react";
import { useAuth } from "../Common/AuthProvider";
import { AppHeader } from "../Common/AppHeader";
import { PokemonSearch } from "./PokemonSearch";
import { PokemonCard } from "./PokemonCard";
import { useRouter } from "next/router";

export const PokemonPage: FC = () => {
  const { accessToken, keycloak } = useAuth();

  const isSearchable = useMemo(
    () =>
      !!keycloak.authenticated &&
      keycloak.hasResourceRole("readonly", "api-pokemon"),
    [keycloak]
  );
  const isEditable = useMemo(
    () =>
      !!keycloak.authenticated &&
      keycloak.hasResourceRole("editor", "api-pokemon"),
    [keycloak]
  );

  const name = useRouter().query.name as string | undefined;

  return (
    <>
      <Head>
        <title>{name ? `Pokemon ${name}` : "Pokemon"}</title>
      </Head>
      <nav>
        <Container>
          <AppHeader resourceServer={"api-pokemon"} />
        </Container>
        <Container>
          {accessToken && (
            <PokemonSearch disabled={!isSearchable} accessToken={accessToken} />
          )}
        </Container>
      </nav>
      <main>
        <Container>
          {name && accessToken && (
            <PokemonCard
              name={name}
              accessToken={accessToken}
              isEditable={isEditable}
            />
          )}
        </Container>
      </main>
    </>
  );
};
