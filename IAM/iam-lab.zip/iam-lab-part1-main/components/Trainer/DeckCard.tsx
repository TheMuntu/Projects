import { AddIcon, NotAllowedIcon, SmallCloseIcon } from "@chakra-ui/icons";
import {
  Box,
  Button,
  Divider,
  HStack,
  IconButton,
  Image,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  SimpleGrid,
  Spinner,
} from "@chakra-ui/react";
import { debounce } from "lodash-es";
import { FC, useEffect, useMemo, useRef, useState } from "react";
import { IPokemon } from "../../server/pokemon-service";
import { useDeck, useDeleteDeck, useUpdateDeck } from "./useApiTrainer";

export const DeckCard: FC<{
  token: string;
  username: string;
  name: string;
  displayUsername?: boolean;
  onDelete?: () => void;
}> = ({ token, username, name, displayUsername, onDelete }) => {
  const { deck, setDeck } = useDeck({
    username,
    name,
    token,
  });

  const { isUpdating, updateDeck } = useUpdateDeck();
  const { isDeleting, deleteDeck } = useDeleteDeck();

  const pokemons = deck?.pokemons || [];
  if (!deck) {
    return (
      <Box borderWidth="1px" borderRadius="lg" p={4}>
        <Box fontWeight="bold" as="h2" isTruncated>
          {name}
        </Box>
      </Box>
    );
  }
  return (
    <Box borderWidth="1px" borderRadius="lg" p={4}>
      <HStack alignItems={"flex-start"}>
        <Box flexShrink={0} fontWeight="bold" as="h2" isTruncated>
          {name}
        </Box>
        <Box flexGrow={1} />
        {onDelete && (
          <Button
            onClick={() =>
              deleteDeck({
                token,
                name,
                username,
                onDelete,
              })
            }
          >
            {"Delete"}
          </Button>
        )}
        {displayUsername && <Box flexShrink={0}>{username}</Box>}
      </HStack>
      <SimpleGrid mt={2} columns={3} spacing={2}>
        {pokemons.map((pokemon, index) => {
          return (
            <PokemonMiniCard
              key={index}
              token={token}
              name={pokemon}
              onDelete={() => {
                updateDeck({
                  pokemons: pokemons.filter((_, i) => i !== index),
                  token,
                  username,
                  name,
                  onUpdate: setDeck,
                });
              }}
            />
          );
        })}
      </SimpleGrid>
      {pokemons.length < 6 && (
        <AddPokemon
          onAdd={(pokemonName) => {
            updateDeck({
              pokemons: [...pokemons, pokemonName],
              token,
              username,
              name,
              onUpdate: setDeck,
            });
          }}
          token={token}
        />
      )}
    </Box>
  );
};

const PokemonMiniCard: FC<{
  token: string;
  name: string;
  onDelete: () => void;
}> = ({ token, name, onDelete }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<IPokemon | null>(null);

  useEffect(() => {
    const abr = new AbortController();
    setIsLoading(true);
    fetch(`/api/pokemon/${name}`, {
      method: "GET",
      headers: {
        authorization: `Bearer ${token}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (
          res.status === 200 &&
          res.headers.get("content-type")?.startsWith("application/json")
        ) {
          return res.json().then((data) => {
            setData(data);
          });
        }
      })
      .finally(() => {
        setIsLoading(false);
      });

    return () => {
      abr.abort();
    };
  }, [name, token]);

  return (
    <Box p={2} borderRadius={"lg"} borderWidth="1px" borderColor={"gray.200"}>
      {data && (
        <Image
          src={
            data.sprites.other["official-artwork"].front_default || undefined
          }
          alt={name}
        />
      )}
      <Divider mt={2} mb={2} />
      <HStack justifyContent={"center"}>
        <Box>{name}</Box>
        <IconButton
          size={"xs"}
          aria-label={""}
          icon={<SmallCloseIcon />}
          onClick={onDelete}
        ></IconButton>
      </HStack>
    </Box>
  );
};

export const AddPokemon: FC<{
  token: string;
  onAdd: (name: string) => void;
}> = ({ token, onAdd }) => {
  const accessTokenRef = useRef<string | undefined>(token);
  accessTokenRef.current = token;

  const [value, setValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isFound, setIsFound] = useState(false);

  const [debouncedValue, _setDebouncedValue] = useState(value);

  const setDebouncedValue = useMemo(
    () => debounce(_setDebouncedValue, 500),
    []
  );

  useEffect(() => {
    setIsLoading(true);
    setDebouncedValue(value);
  }, [value, setDebouncedValue]);

  useEffect(() => {
    if (debouncedValue.length === 0) {
      setIsLoading(false);
      return;
    }
    const abr = new AbortController();
    fetch(`/api/pokemon/${debouncedValue}`, {
      method: "GET",
      headers: {
        authorization: `Bearer ${accessTokenRef.current}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (abr.signal?.aborted) {
          return;
        }
        setIsFound(
          Boolean(
            res.status === 200 &&
              res.headers.get("content-type")?.startsWith("application/json")
          )
        );
      })
      .finally(() => {
        if (abr.signal?.aborted) {
          return;
        }
        setIsLoading(false);
      });
    return () => abr.abort();
  }, [debouncedValue]);

  const handleAdd = () => {
    onAdd(value);
    setValue("");
  };

  return (
    <InputGroup mt={2}>
      <InputLeftElement pointerEvents="none">
        <AddIcon color={"gray.300"} />
      </InputLeftElement>
      <Input
        type="text"
        placeholder={"Add pokemon..."}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={
          isFound && value.length > 0
            ? (e) => e.key === "Enter" && handleAdd()
            : undefined
        }
      />
      <InputRightElement>
        {value.length > 0 &&
          (isLoading ? (
            <Spinner size="sm" />
          ) : isFound ? (
            <IconButton
              size="sm"
              icon={<AddIcon color={"green.400"} />}
              aria-label={value}
              onClick={() => handleAdd()}
            />
          ) : (
            <NotAllowedIcon color={"red.400"} />
          ))}
      </InputRightElement>
    </InputGroup>
  );
};
