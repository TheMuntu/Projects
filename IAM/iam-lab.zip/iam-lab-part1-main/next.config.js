/** @type {import('next').NextConfig} */

const nextConfig = {
  reactStrictMode: true,
  compiler: {
    removeConsole: false,
  },
  async redirects() {
    return [
      {
        source: "/pokemon",
        destination: "/pokemon/bulbasaur",
        permanent: true,
      },
    ];
  },
};

module.exports = nextConfig;
