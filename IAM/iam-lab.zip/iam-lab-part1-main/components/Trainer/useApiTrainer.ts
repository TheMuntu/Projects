import { useCallback, useEffect, useState } from "react";
import { useAsRef } from "../Common/useAsRef";

export type IDeck = {
  name: string;
  pokemons: string[];
};

export type ICreateParams = {
  name: string;
  token: string;
  onCreate: (deck: IDeck) => void;
};

export type IUpdateParams = {
  token: string;
  name: string;
  username: string;
  pokemons: string[];
  onUpdate: (deck: IDeck) => void;
};

export type IDeleteParams = {
  token: string;
  name: string;
  username: string;
  onDelete: () => void;
};

export const useCreateDeck = () => {
  const [params, setParams] = useState<ICreateParams | null>(null);

  useEffect(() => {
    if (!params) {
      return;
    }
    const { token, name, onCreate } = params;
    const abr = new AbortController();
    fetch(`http://localhost:3069/deck-create/${name}`, {
      mode: "cors",
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (
          res.status === 201 &&
          res.headers.get("content-type")?.startsWith("application/json")
        ) {
          return res.json().then((data) => {
            if (!abr.signal.aborted) {
              onCreate(data);
            }
          });
        }
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        setParams(null);
      });
    return () => {
      abr.abort();
    };
  }, [params]);

  const createDeck = useCallback((params: ICreateParams) => {
    setParams(params);
  }, []);

  return {
    isCreating: !!params,
    createDeck,
  };
};

export const useDeck = ({
  username,
  name,
  token,
}: {
  username: string;
  name: string;
  token: string;
}) => {
  const tokenRef = useAsRef(token);
  const [reqId, refresh] = useRefresh();

  const [isLoading, setIsLoading] = useState(true);
  const [deck, setDeck] = useState<IDeck | null>(null);

  useEffect(() => {
    const abr = new AbortController();
    setIsLoading(true);
    setDeck(null);
    fetch(`http://localhost:3069/deck/${username}/${name}`, {
      mode: "cors",
      method: "GET",
      headers: {
        authorization: `Bearer ${tokenRef.current}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (
          res.status === 200 &&
          res.headers.get("content-type")?.startsWith("application/json")
        ) {
          return res.json().then((data) => {
            if (!abr.signal.aborted) {
              setDeck(data);
            }
          });
        }
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
    return () => {
      abr.abort();
    };
  }, [username, name, reqId, tokenRef]);

  return { isLoading, deck, refresh, setDeck };
};

export const useDeckList = (token: string) => {
  const tokenRef = useAsRef(token);
  const [reqId, refresh] = useRefresh();

  const [isLoading, setIsLoading] = useState(true);
  const [deckList, setDeckList] = useState<string[] | null>();

  useEffect(() => {
    const abr = new AbortController();
    setIsLoading(true);
    fetch(`http://localhost:3069/deck-list`, {
      mode: "cors",
      method: "GET",
      headers: {
        authorization: `Bearer ${tokenRef.current}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (
          res.status === 200 &&
          res.headers.get("content-type")?.startsWith("application/json")
        ) {
          return res.json().then((data) => {
            if (!abr.signal.aborted) {
              setDeckList(data);
            }
          });
        }
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
    return () => {
      abr.abort();
    };
  }, [reqId, tokenRef]);

  return { isLoading, deckList, refresh };
};

export const useUpdateDeck = () => {
  const [params, setParams] = useState<IUpdateParams | null>(null);

  useEffect(() => {
    if (!params) {
      return;
    }

    const { token, name, username, pokemons, onUpdate } = params;

    const abr = new AbortController();
    fetch(`http://localhost:3069/deck/${username}/${name}`, {
      mode: "cors",
      method: "PATCH",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(pokemons),
      signal: abr.signal,
    })
      .then((res) => {
        if (
          res.status === 200 &&
          res.headers.get("content-type")?.startsWith("application/json")
        ) {
          return res.json().then((data) => {
            if (!abr.signal.aborted) {
              onUpdate(data);
            }
          });
        }
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        setParams(null);
      });
    return () => {
      abr.abort();
    };
  }, [params]);

  const updateDeck = useCallback((params: IUpdateParams) => {
    setParams(params);
  }, []);

  return {
    isUpdating: !!params,
    updateDeck,
  };
};

export const useDeleteDeck = () => {
  const [params, setParams] = useState<IDeleteParams | null>(null);

  useEffect(() => {
    if (!params) {
      return;
    }

    const { token, name, username, onDelete } = params;

    const abr = new AbortController();
    fetch(`http://localhost:3069/deck/${username}/${name}`, {
      mode: "cors",
      method: "DELETE",
      headers: {
        authorization: `Bearer ${token}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (res.status === 204) {
          if (!abr.signal.aborted) {
            onDelete();
          }
        }
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        setParams(null);
      });
    return () => {
      abr.abort();
    };
  }, [params]);

  const deleteDeck = useCallback((params: IDeleteParams) => {
    setParams(params);
  }, []);

  return {
    isDeleting: !!params,
    deleteDeck,
  };
};

const useRefresh = (): [number, () => void] => {
  const [reqId, setReqId] = useState(0);
  const refresh = useCallback(() => {
    setReqId((prev) => prev + 1);
  }, []);
  return [reqId, refresh];
};
