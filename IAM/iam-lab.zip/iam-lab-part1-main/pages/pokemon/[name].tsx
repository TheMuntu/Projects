import { AuthProvider } from "../../components/Common/AuthProvider";
import { PokemonPage } from "../../components/Pokemon/PokemonPage";

export default function PokemonName() {
  return (
    <AuthProvider
      config={"/keycloak-pokemon.json"}
      // ssoRedirect={"/pokemon/silent-check-sso.html"}
    >
      <PokemonPage />
    </AuthProvider>
  );
}
