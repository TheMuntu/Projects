import { AuthProvider } from "../../components/Common/AuthProvider";
import { TrainerPage } from "../../components/Trainer/TrainerPage";

export default function TrainerIndex() {
  return (
    <AuthProvider
      config={"/keycloak-trainer.json"}
      // ssoRedirect={"/trainer/silent-check-sso.html"}
    >
      <TrainerPage />
    </AuthProvider>
  );
}
