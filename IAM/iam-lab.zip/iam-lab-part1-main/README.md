## Launch

- Install node lts - <https://nodejs.org/en/>
- Install dependencies ans run

```sh
      npm install --global yarn
      yarn install
      yarn dev
```

- App should be available at `http://localhost:3068`
