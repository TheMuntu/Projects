import { HStack, Input, Button } from "@chakra-ui/react";
import { FC, useState } from "react";
import { useCreateDeck } from "./useApiTrainer";

export const NewDeck: FC<{ token: string; onCreate: () => void }> = ({
  token,
  onCreate,
}) => {
  const { isCreating, createDeck } = useCreateDeck();

  const [name, setName] = useState("");

  return !token ? null : (
    <HStack mt={4} spacing={2}>
      <Input
        type={"text"}
        value={name}
        placeholder={"New Deck"}
        onChange={(e) => setName(e.target.value)}
      />
      <Button
        type="button"
        disabled={!name}
        isLoading={isCreating}
        onClick={() => {
          createDeck({
            name,
            token,
            onCreate: () => {
              onCreate();
              setName("");
            },
          });
        }}
      >
        {"Add deck"}
      </Button>
    </HStack>
  );
};
