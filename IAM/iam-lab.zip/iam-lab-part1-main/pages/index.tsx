import { Container, Link, List, ListItem } from "@chakra-ui/react";

export default function IndexPage() {
  return (
    <nav>
      <Container p={4}>
        <List>
          <ListItem>
            <Link color="blue.300" href={"/pokemon/bulbasaur"} isExternal>
              {"Pokemon"}
            </Link>
          </ListItem>
          <ListItem>
            <Link color="blue.300" href={"/trainer"} isExternal>
              {"Trainer"}
            </Link>
          </ListItem>
        </List>
      </Container>
    </nav>
  );
}
