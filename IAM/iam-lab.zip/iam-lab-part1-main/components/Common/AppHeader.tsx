import { Button, HStack, Text } from "@chakra-ui/react";
import { FC } from "react";
import { useAuth } from "./AuthProvider";

export const AppHeader: FC<{ resourceServer: string }> = ({
  resourceServer,
}) => {
  const { keycloak } = useAuth();
  return (
    <HStack p={2} spacing={4}>
      <Text>{keycloak.clientId}</Text>
      {keycloak && (
        <Text>
          {keycloak.idTokenParsed?.preferred_username || "unauthenticated"}
        </Text>
      )}
      {keycloak && (
        <Text>
          {keycloak.tokenParsed?.resource_access?.[resourceServer]?.roles?.join(
            ", "
          )}
        </Text>
      )}
      <LoginLogout />
    </HStack>
  );
};

const LoginLogout: FC = () => {
  const { keycloak } = useAuth();
  return keycloak.authenticated ? (
    <Button onClick={() => keycloak.logout()}>{"Logout"}</Button>
  ) : (
    <Button onClick={() => keycloak.login()}>{"Login"}</Button>
  );
};
