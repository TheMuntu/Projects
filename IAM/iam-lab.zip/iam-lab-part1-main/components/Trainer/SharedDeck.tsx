import { Box, Button, HStack, Input } from "@chakra-ui/react";
import { FC, useState } from "react";
import { DeckCard } from "./DeckCard";

export const SharedDeck: FC<{ token: string }> = ({ token }) => {
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");

  const [submitted, setSubmitted] = useState<{
    username: string;
    name: string;
  } | null>(null);

  return (
    <Box>
      <HStack mb={4}>
        <Input
          type="text"
          name="trainer-name"
          placeholder="Username"
          value={username}
          onChange={(e) => {
            setUsername(e.target.value);
          }}
        />
        <Input
          type="text"
          name="deck-name"
          placeholder="Deckname"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Button
          flexShrink={0}
          type="button"
          onClick={() => setSubmitted({ username, name })}
        >
          {"LookUp"}
        </Button>
      </HStack>
      {submitted && (
        <DeckCard
          token={token}
          name={submitted.name}
          username={submitted.username}
          displayUsername={true}
        />
      )}
    </Box>
  );
};
