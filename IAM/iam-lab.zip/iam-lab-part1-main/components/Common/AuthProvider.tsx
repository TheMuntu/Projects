import Keycloak from "keycloak-js";
import {
  createContext,
  FC,
  ReactElement,
  useContext,
  useEffect,
  useState,
} from "react";

export type IAuthContext = {
  accessToken: string | null;
  keycloak: Keycloak.KeycloakInstance;
};

const ctx = createContext<IAuthContext>(null!);

export const AuthProvider: FC<{
  config: string;
  ssoRedirect?: string;
}> = ({ config, ssoRedirect, children }) => {
  const auth = useInitAuth(config, ssoRedirect);
  return !auth ? null : <ctx.Provider value={auth}>{children}</ctx.Provider>;
};

export const useAuth = () => {
  return useContext(ctx);
};

const useInitAuth = (config: string, ssoRedirect?: string) => {
  const [auth, setAuth] = useState<IAuthContext | null>(null);

  useEffect(() => {
    setAuth(null);

    const keycloak = Keycloak(config);

    const onAuthUpdate = () => {
      setAuth({ keycloak, accessToken: keycloak.token ?? null });
    };

    keycloak
      .init(
        ssoRedirect
          ? {
              onLoad: "check-sso",
              silentCheckSsoRedirectUri: `${window.location.origin}${ssoRedirect}`,
            }
          : { checkLoginIframe: false }
      )
      .then(() => {
        onAuthUpdate();
      })
      .catch(console.error);

    keycloak.onAuthRefreshSuccess = () => {
      onAuthUpdate();
    };

    return () => {
      keycloak.clearToken();
    };
  }, [config, ssoRedirect]);

  return auth;
};
