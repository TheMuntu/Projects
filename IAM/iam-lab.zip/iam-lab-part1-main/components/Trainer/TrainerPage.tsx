import { Container } from "@chakra-ui/react";
import Head from "next/head";
import { FC } from "react";
import { AppHeader } from "../Common/AppHeader";
import { TrainerDecks } from "./TrainerDecks";

export const TrainerPage: FC = () => {
  return (
    <>
      <Head>
        <title>{`Trainer`}</title>
      </Head>
      <nav>
        <Container>
          <AppHeader resourceServer={"api-trainer"} />
        </Container>
      </nav>
      <main>
        <Container>
          <TrainerDecks />
        </Container>
      </main>
    </>
  );
};
