// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from "next";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<string>
) {
  if (req.method === "GET") {
    res.status(200).send("0.0.1");
  } else {
    res.status(403).send("Method Not Allowed");
  }
}
