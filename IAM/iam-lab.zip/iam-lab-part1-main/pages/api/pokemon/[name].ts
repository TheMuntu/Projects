import type { NextApiRequest, NextApiResponse } from "next";
import {
  getPokemon,
  IPokemon,
  updatePokemon,
  validateUpdate,
} from "../../../server/pokemon-service";
import { IAccessError, verifyAccess } from "../../../server/verify-access";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<IPokemon | string>
) {
  if (req.method === "GET") {
    const [accessErr] = verifyAccess({
      req,
      service: "api-pokemon",
      roles: ["readonly"],
    });
    if (accessErr) {
      handleAccessError(res, accessErr);
    } else {
      const { name } = req.query;
      const [, data] = await getPokemon(name as string);
      if (data) {
        res.status(200).json(data);
      } else {
        res.status(404).json("Not found");
      }
    }
  } else if (req.method === "PUT") {
    const [accessErr] = verifyAccess({
      req,
      service: "api-pokemon",
      roles: ["editor"],
    });
    if (accessErr) {
      handleAccessError(res, accessErr);
    } else {
      const { name } = req.query;
      const update = req.body;
      const [, validated] = validateUpdate(update);
      if (validated) {
        const [, pokemon] = await updatePokemon(name as string, validated);
        if (pokemon) {
          res.status(200).json(pokemon);
        } else {
          res.status(404).json("Not found");
        }
      } else {
        res.status(400).json("Bad Request");
      }
    }
  } else {
    res.status(403).json("Method Not Allowed");
  }
}

const handleAccessError = (res: NextApiResponse, err: IAccessError) => {
  if (err.kind === "role-is-missing") {
    res.status(403).json(`Forbidden: Role "${err.role}" is missing`);
  } else if (err.kind === "token-is-bad") {
    res.status(401).json("Unauthorized: Token is invalid");
  } else if (err.kind === "token-is-missing") {
    res.status(401).json("Unauthorized: Token is missing");
  }
};
