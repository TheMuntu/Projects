import { ArrowRightIcon, NotAllowedIcon, Search2Icon } from "@chakra-ui/icons";
import {
  Box,
  IconButton,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  Spinner,
} from "@chakra-ui/react";
import { debounce } from "lodash-es";
import { useRouter } from "next/router";

import { FC, useEffect, useMemo, useRef, useState } from "react";

export const PokemonSearch: FC<{ disabled: boolean; accessToken: string }> = ({
  disabled = false,
  accessToken,
}) => {
  const accessTokenRef = useRef<string | undefined>(accessToken);
  useEffect(() => {
    accessTokenRef.current = accessToken;
  }, [accessToken]);

  const router = useRouter();
  const [value, setValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isFound, setIsFound] = useState(false);

  const [debouncedValue, _setDebouncedValue] = useState(value);

  const setDebouncedValue = useMemo(
    () => debounce(_setDebouncedValue, 500),
    []
  );

  useEffect(() => {
    setIsLoading(true);
    setDebouncedValue(value);
  }, [value, setDebouncedValue]);

  useEffect(() => {
    if (debouncedValue.length === 0) {
      setIsLoading(false);
      return;
    }
    const abr = new AbortController();
    fetch(`/api/pokemon/${debouncedValue}`, {
      method: "GET",
      headers: {
        authorization: `Bearer ${accessTokenRef.current}`,
      },
      signal: abr.signal,
    })
      .then((res) => {
        if (abr.signal?.aborted) {
          return;
        }
        setIsFound(
          Boolean(
            res.status === 200 &&
              res.headers.get("content-type")?.startsWith("application/json")
          )
        );
      })
      .finally(() => {
        if (abr.signal?.aborted) {
          return;
        }
        setIsLoading(false);
      });
    return () => abr.abort();
  }, [debouncedValue]);

  const goToPokemon = () => {
    router.push(`/pokemon/${value}`);
    setValue("");
  };

  return (
    <Box p={2}>
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <Search2Icon color={"gray.300"} />
        </InputLeftElement>
        <Input
          type="text"
          placeholder={"Search pokemon..."}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          disabled={disabled}
          onKeyDown={
            isFound && value.length > 0
              ? (e) => e.key === "Enter" && goToPokemon()
              : undefined
          }
        />
        <InputRightElement>
          {value.length > 0 &&
            (isLoading ? (
              <Spinner size="sm" />
            ) : isFound ? (
              <IconButton
                size="sm"
                icon={<ArrowRightIcon color={"green.400"} />}
                aria-label={value}
                onClick={goToPokemon}
              />
            ) : (
              <NotAllowedIcon color={"red.400"} />
            ))}
        </InputRightElement>
      </InputGroup>
    </Box>
  );
};
