import { Box } from "@chakra-ui/react";
import { FC } from "react";
import { DeckCard } from "./DeckCard";
import { NewDeck } from "./NewDeck";
import { useDeckList } from "./useApiTrainer";

export const DeckList: FC<{
  token: string;
  username: string;
}> = ({ token, username }) => {
  const { deckList, refresh } = useDeckList(token);
  return (
    <Box>
      {deckList &&
        deckList.map((deck) => (
          <DeckCard
            key={deck}
            token={token}
            username={username}
            name={deck}
            onDelete={refresh}
          />
        ))}
      <NewDeck token={token} onCreate={refresh} />
    </Box>
  );
};
