import jwt from "jsonwebtoken";
import { get } from "lodash-es";
import { NextApiRequest } from "next";

const cert =
  "-----BEGIN CERTIFICATE-----\nMIICmzCCAYMCBgGAJsz7DjANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZhc19sYWIwHhcNMjIwNDE0MDYzODI5WhcNMzIwNDE0MDY0MDA5WjARMQ8wDQYDVQQDDAZhc19sYWIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCPS7e3dKUc9vpAkqZPXUPJhvUZR2k2lftwDS/V3ivBX8sY0k31yCNkUQxOFR1bIlPJP6fbek5pYF3vgfH35vhWlCHlixCb9TDffTiVMOImNHOm0Q1QsLRJqP6YstjaF+/tTC+QFWqnCfh30xSl00dU9lJoSFHx1ztBYKQ9JKzTT0bbTdl7jaNXOe3PEdX6L9DmSITHF4GX1rCg0642uPu7SL6z8/aYhmQp9KBnLbXqwKpmyoGuogNgyM7j4xKtne2p4tDJ8AaW4ww2+mbVaSamoKJsx4Np8PW0RdzKtsOmMElrx14kuLafh/xXuNwmXE0iyEhCikInw2QJlooPE0xjAgMBAAEwDQYJKoZIhvcNAQELBQADggEBACvMn0Wx7wZOGOYBOKqRGAgyJkZAi65tCnTR4TVT+NFqpHh5UXyjNPpVbJT52tBgDTNmRBbsldEHNp7C6eRntmLLC8HKLoHZzsrFUcsQ79z2runFpfoYcgS0/H9wcZ1HmtCBmZLayC5kY0ey8yGJEl3U3MJQSvAwKL7KGTeGKeVwpsakjzdf9zJuxTS4n7f6xLFltHLrEQPweKTJEhh+bWhJWoNk2IslfeAma5qcCZzdQS4NS66fP/ljQ7MqwCK0E2tFCoSQE3pa59xAewvm5Wt05tgyKc/ItxpUZuvO26LDzY1b5BauFcOEJDmHzIIMdkhx/D9Sp7rN2HGo6PP0b6c=\n-----END CERTIFICATE-----";

export type ITokenIsMissing = { kind: "token-is-missing" };
export type ITokenIsBad = { kind: "token-is-bad" };
export type IRoleIsMissing = { kind: "role-is-missing"; role: string };

export type IAccessError = ITokenIsMissing | ITokenIsBad | IRoleIsMissing;

export const verifyAccess = (params: {
  req: NextApiRequest;
  service: string;
  roles: string[];
}): IResult<true, IAccessError> => {
  const { req, service, roles } = params;
  const header = req.headers["authorization"];

  if (header && header.startsWith("Bearer ")) {
    const token = header.substring(7);
    let payload;
    try {
      payload = jwt.verify(token, cert, {
        algorithms: ["RS256"],
        audience: service,
      });
    } catch {}
    if (typeof payload === "object" && payload !== null) {
      const resourceRoles = get(payload, `resource_access.${service}.roles`);
      if (Array.isArray(resourceRoles)) {
        const allowedRoles = new Set(resourceRoles);
        const missingRole = roles.find((role) => !allowedRoles.has(role));
        if (missingRole) {
          return [{ kind: "role-is-missing", role: missingRole }];
        } else {
          return [null, true];
        }
      }
    }
    return [{ kind: "token-is-bad" }];
  }
  return [{ kind: "token-is-missing" }];
};
