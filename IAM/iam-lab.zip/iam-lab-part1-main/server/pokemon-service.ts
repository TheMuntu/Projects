import Ajv, {
  type JTDSchemaType,
  type ValidateFunction,
  type ErrorObject,
} from "ajv/dist/jtd";
import axios from "axios";
import { merge } from "lodash-es";

// https://pokeapi.co/docs/v2
const pokemonEndpoint = "https://pokeapi.co/api/v2/";

declare global {
  var pokemonStore: Map<string, IPokemon>;
}

if (!global.pokemonStore) {
  global.pokemonStore = new Map<string, IPokemon>();
}

export type IPokemon = {
  name: string;
  height: number;
  weight: number;
  sprites: {
    back_default: string | null;
    back_female: string | null;
    back_shiny: string | null;
    back_shiny_female: string | null;
    front_default: string | null;
    front_female: string | null;
    front_shiny: string | null;
    front_shiny_female: string | null;
    other: {
      "official-artwork": {
        front_default: string | null;
      };
    };
  };
  stats: Array<{
    base_stat: number;
    stat: {
      name: string;
      url: string | null;
    };
  }>;
  abilities: Array<{
    ability: {
      name: string;
      url: string | null;
    };
  }>;
};

type IPokemonUpdate = PartialDeep<Omit<IPokemon, "name">>;

export const ajv = new Ajv({
  removeAdditional: true,
});

const updateSchema: JTDSchemaType<IPokemonUpdate> = {
  optionalProperties: {
    height: { type: "int32" },
    weight: { type: "int32" },
    sprites: {
      optionalProperties: {
        back_default: { type: "string", nullable: true },
        back_female: { type: "string", nullable: true },
        back_shiny: { type: "string", nullable: true },
        back_shiny_female: { type: "string", nullable: true },
        front_default: { type: "string", nullable: true },
        front_female: { type: "string", nullable: true },
        front_shiny: { type: "string", nullable: true },
        front_shiny_female: { type: "string", nullable: true },
        other: {
          optionalProperties: {
            "official-artwork": {
              optionalProperties: {
                front_default: {
                  type: "string",
                  nullable: true,
                },
              },
            },
          },
        },
      },
    },
    stats: {
      elements: {
        optionalProperties: {
          base_stat: { type: "int32" },
          stat: {
            optionalProperties: {
              name: { type: "string" },
              url: { type: "string", nullable: true },
            },
          },
        },
      },
    },
    abilities: {
      elements: {
        optionalProperties: {
          ability: {
            optionalProperties: {
              name: { type: "string" },
              url: { type: "string", nullable: true },
            },
          },
        },
      },
    },
  },
};

const makeValidate =
  <T>(validator: ValidateFunction<T>) =>
  (data: unknown): IResult<T, ErrorObject[]> => {
    if (validator(data)) {
      return [null, data];
    } else {
      return [validator.errors!];
    }
  };

export const validateUpdate = makeValidate(ajv.compile(updateSchema));

const createSchema: JTDSchemaType<IPokemon> = {
  properties: {
    name: { type: "string" },
    height: { type: "int32" },
    weight: { type: "int32" },
    sprites: {
      properties: {
        back_default: { type: "string", nullable: true },
        back_female: { type: "string", nullable: true },
        back_shiny: { type: "string", nullable: true },
        back_shiny_female: { type: "string", nullable: true },
        front_default: { type: "string", nullable: true },
        front_female: { type: "string", nullable: true },
        front_shiny: { type: "string", nullable: true },
        front_shiny_female: { type: "string", nullable: true },
        other: {
          properties: {
            "official-artwork": {
              properties: {
                front_default: { type: "string", nullable: true },
              },
            },
          },
        },
      },
    },
    stats: {
      elements: {
        properties: {
          base_stat: { type: "int32" },
          stat: {
            properties: {
              name: { type: "string" },
              url: { type: "string", nullable: true },
            },
          },
        },
      },
    },
    abilities: {
      elements: {
        properties: {
          ability: {
            properties: {
              name: { type: "string" },
              url: { type: "string", nullable: true },
            },
          },
        },
      },
    },
  },
};

const validateCreate = makeValidate(ajv.compile(createSchema));

type IPokemonNotFound = { kind: "pokemon-not-found" };

export async function getPokemon(
  name: string
): Promise<IResult<IPokemon, IPokemonNotFound>> {
  const stored = pokemonStore.get(name);
  if (stored) {
    return [null, stored];
  }
  const [, data]: IResult<IPokemon, ErrorObject[] | Error> = await axios
    .get<IPokemon>(`${pokemonEndpoint}/pokemon/${name}`)
    .then((response) => validateCreate(response.data))
    .catch((err: Error) => [err]);
  if (data) {
    pokemonStore.set(name, data);
    return [null, data];
  }
  return [{ kind: "pokemon-not-found" }];
}

export async function updatePokemon(
  name: string,
  update: IPokemonUpdate
): Promise<IResult<IPokemon, IPokemonNotFound>> {
  const res = await getPokemon(name);
  if (res[1]) {
    merge(res[1], update);
  }
  return res;
}
