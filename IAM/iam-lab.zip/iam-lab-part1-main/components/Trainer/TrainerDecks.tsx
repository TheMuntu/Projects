import { Box, Heading } from "@chakra-ui/react";
import { useMemo, FC } from "react";
import { useAuth } from "../Common/AuthProvider";
import { DeckList } from "./DeckList";
import { SharedDeck } from "./SharedDeck";

export const TrainerDecks: FC = () => {
  const auth = useAuth();

  const { accessToken } = auth;
  const username = useMemo(
    () => auth.keycloak.idTokenParsed?.preferred_username ?? null,
    [auth]
  );

  if (!accessToken || !username) {
    return null;
  }

  return (
    <Box p={2}>
      <Heading mb={4} as="h4" size="md">
        {"Deck List"}
      </Heading>
      <DeckList token={accessToken} username={username} />
      <Heading mt={8} mb={4} as="h4" size="md">
        {"Lookup shared decks"}
      </Heading>
      <SharedDeck token={accessToken} />
    </Box>
  );
};
