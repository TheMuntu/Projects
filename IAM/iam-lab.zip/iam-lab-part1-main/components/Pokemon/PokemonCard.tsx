import { cloneDeep, debounce, get, isEqual, set, upperFirst } from "lodash-es";
import {
  type FC,
  useEffect,
  useState,
  useCallback,
  ChangeEvent,
  useRef,
  useMemo,
} from "react";
import { type IPokemon } from "../../server/pokemon-service";
import Image from "next/image";
import {
  Badge,
  Box,
  FormControl,
  FormLabel,
  Heading,
  HStack,
  Input,
  SimpleGrid,
  Spinner,
  Text,
  VStack,
} from "@chakra-ui/react";
import { NotAllowedIcon } from "@chakra-ui/icons";

export type IData = Omit<IPokemon, "name">;

export const PokemonCard: FC<{
  name: string;
  accessToken: string;
  initialData?: IData;
  isEditable?: boolean;
}> = ({ name, initialData = null, isEditable, accessToken }) => {
  const accessTokenRef = useRef<string | undefined>(accessToken);
  useEffect(() => {
    accessTokenRef.current = accessToken;
  }, [accessToken]);

  const isDisabled = !isEditable || !accessToken;
  const serverDataRef = useRef<IData | null>(initialData);

  const [isQueued, setIsQueued] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [inputData, setInputData] = useState<IData | null>(initialData);

  const [dataToSend, _setDataToSend] = useState<IData | null>(initialData);
  const setDataToSend = useMemo(
    () =>
      debounce((data: IData) => {
        _setDataToSend(data);
        setIsQueued(false);
      }, 500),
    []
  );

  useEffect(() => {
    if (inputData) {
      setIsQueued(true);
      setDataToSend(inputData);
    }
  }, [inputData, setDataToSend]);

  const makeRequest = useCallback((...request: Parameters<typeof fetch>) => {
    setIsLoading(true);
    const signal = request[1]?.signal;
    fetch(...request)
      .then((res) => {
        parsePokemon(
          res,
          ({ name, ...rest }) => {
            if (signal?.aborted) {
              return;
            }
            serverDataRef.current = rest;
            setInputData(rest);
          },
          () => {
            if (signal?.aborted) {
              return;
            }
            setInputData(serverDataRef.current);
            setIsError(true);
          }
        );
      })
      .finally(() => {
        if (signal?.aborted) {
          return;
        }
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    if (initialData) {
      setInputData(initialData);
      _setDataToSend(initialData);
      return;
    }
    const abr = new AbortController();
    makeRequest(`/api/pokemon/${name}`, {
      method: "GET",
      headers: {
        authorization: `Bearer ${accessTokenRef.current}`,
      },
      signal: abr.signal,
    });
    return () => abr.abort();
  }, [initialData, name, makeRequest]);

  const onChange = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    const { name, value, valueAsNumber } = e.target;
    setInputData((prev) => {
      if (!prev) {
        return null;
      }
      const o = cloneDeep(prev);
      set(o, name, !Number.isNaN(valueAsNumber) ? valueAsNumber : value);
      return o;
    });
  }, []);

  const isChanged = useMemo(
    () => !isEqual(dataToSend, serverDataRef.current),
    [dataToSend]
  );
  useEffect(() => {
    if (!isChanged) {
      return;
    }
    const abr = new AbortController();
    makeRequest(`/api/pokemon/${name}`, {
      method: "PUT",
      headers: {
        "content-type": "application/json; charset=utf-8",
        authorization: `Bearer ${accessTokenRef.current}`,
      },
      body: JSON.stringify(dataToSend),
      signal: abr.signal,
    });
    return () => abr.abort();
  }, [isChanged, name, dataToSend, makeRequest]);

  if (!inputData) {
    return (
      <VStack w="100%" p={4} spacing={4} align={"start"}>
        <HStack spacing={4}>
          <Heading>{upperFirst(name)}</Heading>
          {isError ? (
            <NotAllowedIcon color={"red.400"} />
          ) : isQueued || isLoading ? (
            <Spinner />
          ) : null}
        </HStack>
        <Text>{"Not Found"}</Text>
      </VStack>
    );
  }

  return (
    <VStack w="100%" p={2} spacing={4} align={"start"}>
      <HStack spacing={4}>
        <Heading>{upperFirst(name)}</Heading>
        {isError ? (
          <NotAllowedIcon color={"red.400"} />
        ) : isQueued || isLoading ? (
          <Spinner />
        ) : null}
      </HStack>
      <HStack spacing={2}>
        {inputData.abilities.map(({ ability: { name } }) => (
          <Badge key={name}>{name}</Badge>
        ))}
      </HStack>
      <Box>{pokemonImage(name, inputData.sprites)}</Box>
      <HStack>{sprites(inputData.sprites)}</HStack>
      <SimpleGrid columns={2} spacing={4}>
        <Field
          name={"height"}
          label={"Height"}
          type={"number"}
          data={inputData}
          onChange={onChange}
          disabled={isDisabled}
        />
        <Field
          name={"weight"}
          label={"Weight"}
          type={"number"}
          data={inputData}
          onChange={onChange}
          disabled={isDisabled}
        />
      </SimpleGrid>
      <SimpleGrid columns={2} spacing={4}>
        {inputData.stats.map((stat, index) => {
          return (
            <Field
              key={stat.stat.name}
              label={upperFirst(stat.stat.name.replace("-", " "))}
              name={`stats[${index}].base_stat`}
              type={"number"}
              data={inputData}
              onChange={onChange}
              disabled={isDisabled}
            />
          );
        })}
      </SimpleGrid>
    </VStack>
  );
};

const parsePokemon = (
  res: Response,
  onData: (pokemon: IPokemon) => void,
  onError?: (res: Response) => void
) => {
  if (
    res.status === 200 &&
    res.headers.get("content-type")?.startsWith("application/json")
  ) {
    return res.json().then((data) => {
      onData(data);
    });
  } else {
    if (onError) {
      onError(res);
    } else {
      console.error("Could not parse response");
    }
  }
};

const pokemonImage = (name: string, sprites: IPokemon["sprites"]) => {
  const src = sprites.other["official-artwork"].front_default;
  return (
    src && (
      <Image
        unoptimized
        src={src}
        alt={`image of ${name}`}
        height={96}
        width={96}
      />
    )
  );
};

const sprites = (sprites: IPokemon["sprites"]) => {
  return (Object.keys(sprites) as Array<keyof typeof sprites>).map((key) => {
    const value = sprites[key];
    if (typeof value === "string") {
      return (
        <Image
          unoptimized
          key={key}
          src={value}
          alt={`image varient ${key}`}
          height={48}
          width={48}
        />
      );
    }
    return null;
  });
};

const Field = (props: {
  name: string;
  label: string;
  type: string;
  data: IData;
  onChange: (e: ChangeEvent<HTMLInputElement>) => void;
  disabled: boolean;
}) => {
  const { label, name, type, data, onChange, disabled } = props;
  const value = get(data, name);
  const id = `id-${name}`;
  return (
    <FormControl>
      <FormLabel htmlFor={id}>{label}</FormLabel>
      <Input
        id={id}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        disabled={disabled}
      />
    </FormControl>
  );
};
